#ifndef NODE_H
#define NODE_H

struct Node
{
    int mKey;

    Node *mpParent;
    Node *mpLeft;
    Node *mpRight;

};

#endif // NODE_H
