#include <iostream>

#include "tree.h"

using std::cout;

void showTree(Node *pNode, int l)
{
    if (pNode != nullptr)
    {
        showTree(pNode ->mpLeft, l + 1);
        for (int i{0}; i < l; i++)
        {
            cout << ' ';
            cout << pNode->mKey <<'\n';
            showTree(pNode->mpRight, l + 1);
        }
    }
}

Node *Tree::createRootBST(int data)
{

    Node *pNode = new Node;
    pNode->mKey = data;
    pNode->mpParent = nullptr;
    pNode->mpLeft = nullptr;

    return pNode;
}


