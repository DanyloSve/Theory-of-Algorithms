#ifndef TREE_H
#define TREE_H

#include "node.h"

class Tree
{
public:
    Tree();
    static void searchNodeBST();
    Node *createRootBST(int data);
    Node insertNodeBST();
    static void deleteNodeBST();
    static void successorNodeBST();
    static void predecessorNodeBST();
};

#endif // TREE_H
