#include <iostream>

#include "mySort.h"

using std::cout;
using std::cin;

int main()
{
    MySort A;
    int sizeOfArray = 0;
    while (true)
    {
        cout << "Input:\n"
                " 1 to add iteam to array\n"
                " 2 to sort\n"
                " 3 to randomized sort\n"
                " 4 to order static\n"
                " 5 to exit\n";
        int response;
        cout << "Your response: ";
        cin >> response;

        switch(response)
        {
        case 1:
            cout << "Item to add: ";
            int iteam;
            cin >> iteam;
            A.addIteam(iteam);
            sizeOfArray++;
            break;

        case 2:
            cout << "Sort ";
             A.quickSort(0, sizeOfArray - 1);
            break;

        case 3:
            cout << "Randomized sort: ";
            A.randomizedQuickSort(0, sizeOfArray - 1);
            break;

        case 4:
            int k;
            cout << "Input k statistic: ";
            cin >> k;
            cout << A.randomizedSelect(1, sizeOfArray - 1, k);
            cout << '\n';
            break;
        case 5:
            return 0;
        }

        A.show();
        cout <<'\n';
    }
}
